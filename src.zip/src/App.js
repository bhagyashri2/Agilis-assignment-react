import './App.css';
import { Route,Routes } from 'react-router-dom';
import Home from './pages/home';
import Cart from './pages/cart';
import Header from './components/header';
import Login from './components/Login';
import { Outlet } from 'react-router-dom';

const AuthLayout = () => {
  // logic to protect routes
  return (
    <>
      <Header />
      <Outlet />     
    </>
  );
};

  function App() {
    return (
      <div>       
        <Routes>
          <Route exact path='/' element={<Login/>}/>  {/* default/Initial login page */ }
          <Route element={<AuthLayout />}>
            <Route exact path='/product' element={<Home/>}/> {/* Product page */ }
            <Route exact path='/cart' element={<Cart/>}/> {/* Cart page */ }
          </Route>         
        </Routes>
      </div>
    );
  }

export default App;
