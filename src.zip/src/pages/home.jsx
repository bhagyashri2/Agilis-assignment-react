import { useEffect, useState } from "react";
import { Circles } from "react-loader-spinner";
import ProductTitle from "../components/product-title";

export default function Home() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);

  /* function to fetch product list on homepage */
  async function fetchListOfProducts() {
    setLoading(true);
    const res = await fetch("https://dummyjson.com/products");
    const data = await res.json();
    console.log(data.products);
    if (data) {
      setLoading(false);
      setProducts(data.products);
    }
  }

  useEffect(() => {
    fetchListOfProducts();
  }, []);

  /* to display products on home page */
  return (
    <div>
      {loading ? (
        <div className="min-h-screen w-full flex justify-center items-center">
          <Circles          /* cirlces used to represent border on product item on home page */
            height={"120"}
            width={"120"}
            color="rgb(127,29,29)"
            visible={true}
          />
        </div>
      ) : (
        <div className="min-h-[80vh] grid sm:grid-cols-2 md:grid-cols-3  lg:grid-cols-4 max-w-6xl mx-auto p-3">
       {/* check if there is any product if yes passed product details to product details page using props */}
          {products && products.length
            ? products.map((productItem) => (
                <ProductTitle products={productItem} />     
              ))
            : null}
        </div>
      )}
    </div>
  );
}