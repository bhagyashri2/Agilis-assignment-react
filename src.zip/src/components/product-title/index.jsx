import React from 'react';
import { useDispatch, useSelector } from "react-redux";
import { addToCart, removeFromCart } from '../../store/slices/cart-slice';


export default function ProductTitle({ products }) {

    const dispatch = useDispatch();
    const { cart } = useSelector((state) => state);

    function handleRemoveCart() {
        dispatch(removeFromCart(products.id))
    }

    function handleAddToCart() {
        dispatch(addToCart(products))
    }
/* display products on home page */
    return (
        <div>
            <div className='group flex flex-col items-center border-2 border-red-900 gap-3 p-4 h-[360px] mt-10 ml-5 rounded-xl'>
                <div>  
                    <h3 className="w-40 text-right mt-3 text-gray-700 font-bold text-lg">{products?.price} </h3>
                </div>
                <div className="h-[180px]">
                    <img src={products?.images}
                        alt={products?.title}
                        className='' />
                </div>
            </div>
            <div>
                <h1 className="w-40 truncate mt-3 text-gray-700 font-bold text-lg">{products?.title} </h1>
            </div>
            <div>
                <h3 className="w-40 truncate mt-3 text-gray-700 font-bold text-lg">{products?.description} </h3>
            </div>
            <div className="flex items-center justify-center w-full mt-5">
                <button
                    onClick={cart.some((item) => item.id === products.id) ? handleRemoveCart : handleAddToCart}
                    className="bg-red-950 text-white border-2 rounded-lg font-bold p-4">{
                        cart.some((item) => item.id === products.id) ? 'Remove From Cart' : ' Add to Cart'
                    }
                </button>
            </div>
        </div>
    );
}

