import { Link } from "react-router-dom"

/* Header Routes */
export default function Header() {
    return <div>
        <nav className="flex items-center justify-between h-20 max-w-6xl mx-auto">
            <ul className="flex list-none items-center space-x-6 text-gray-800 font-semibold">
                <Link to={'/'}>
                    <li className="cursor-pointer list-none">
                        Home
                    </li>
                </Link>
                <Link to={'/cart'}>    
                    <li className="cursor-pointer">
                        Cart
                    </li>
                </Link>
            </ul>
        </nav>
    </div>
}