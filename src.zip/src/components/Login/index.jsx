import React from 'react'
import {useState} from 'react';
/* This function check entered username and password is correct */
async function loginUser(credentials) {
    return fetch('https://dummyjson.com/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(credentials)
    })
      .then(data => data.json())
   }

const Login=()=>
    {
       const [username, setUserName] = useState();
       const [password, setPassword] = useState();
     
       const handleSubmit = async e => {
         e.preventDefault();
         /* Passed username and password for authentication*/
         const response = await loginUser({
           username,
           password
         });
         if ('token' in response) {
          /* Matched user details with API user token is stored in localstorage */
           alert("Login Success");          
             localStorage.setItem('accessToken', response['token']);
             localStorage.setItem('username', JSON.stringify(response['username']));
             localStorage.setItem('FirstName', JSON.stringify(response['firstName']));
             window.location.href = "/product";
         } else {
           alert("Login Failed. Please try again", response.message, "error");
         }
       }


  return (
    <div className="main">
        <h1>Login</h1>
        <form noValidate onSubmit={handleSubmit}>
        <div className='columns-md text-right'>
          <div className='login-user-name'>
            <label> Username: </label>        
            <input required type="text" name="username" onChange={e => setUserName(e.target.value)}/><br/>
          </div>
          <div className='login-pass'>
            <label> Password: </label>        
            <input required type="password" name='password' onChange={e => setPassword(e.target.value)}/><br/>
            <br/>          
          </div>
          <button className='btn-submit' type="submit"> Login </button>
        </div>
        </form>
    </div>   
  )
}

export default Login;